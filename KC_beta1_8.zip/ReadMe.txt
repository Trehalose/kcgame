             THE
| | //                     / __/                       ___  ___ ___       O 
| |//   _____  ___   _____ |/    ___  ___   _||_   __ /    \|\\\|\\\ _||_    ___  ___
|   \  /     ||/\ \ /     |||   /   \|/\ \ |_  _||/__|| \\ || _/| _/|_  _|||/   \|/\ \ 
| |\ \ | \\  ||| | || \\  ||\__ |\\ ||| | |  ||  | |  ||  ||||  ||    ||  |||\\ ||| | |
| | \ \|___^_||| | ||___^_|\___\\___/|| | |  ||  | |  ||  ||||  ||    ||  ||\___/|| | |
=======================================================================================
A Japanese language supplimentary learning resource by TheGreatYonR.
=======================================================================================

ABOUT
	"The Kana ContrAPPtion" is meant to be a supplimentary educational tool
	 to help users practice their hiragana and katakana absorption. It is a
	simple tool and was created, also in part, as a programming exercise to
	learn C# and the XNA Framework. It is bulky, and far from elegant, but
	it does the trick and will hopefully provide effective use to those whom
	took the time to try it. Please do enjoy!~

	
HOW TO PLAY
	Open the .exe file(The Kana ContrAPPtion.exe) with the cute little icon.
	To navigate the menu and play, use your Mouse's left-click button.
	Last: Displays the 'romaji' equivolent for the character group you last destroyed.
	Bonus: Displays the 'romaji' equivolent of a character group that gives you extra points.
	Hira+ or Kata+: Hard mode. Own it, yo!
	If you made it that far, you can figure out the rest really...

	
CAN I SAY THE CHARACTERS OUT-LOUD AS I PLAY?
	Yes, I hereby grant you permission to go ahead and do that.


WONT WORK?
	Perhaps you are not running a Windows Operating System.
	Perhaps you lack the .NET Framework 4 Client
		Found Here: http://www.microsoft.com/en-us/download/details.aspx?id=24872
	Perhaps you lack the XNA Framework Redistributable 4.0
		Found Here: http://www.microsoft.com/en-us/download/details.aspx?id=27598
	Perhaps you are dumb.
	Perhaps my coding is faulty (That isn't a perhaps, but lets not focus on my personal problems.)

IS THERE A HARD MODE?
	Yes! You have to pass all of easy mode first. Good luck!~

CREDITS
	Concept, Programming, Graphics, Music, Sound effects*, Etc. by TheGreatYonR.
	* Voice sound effects provided by Google Translate application
	  (trust me, you didnt want to hear my voice)